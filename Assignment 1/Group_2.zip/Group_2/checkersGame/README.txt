Since we made the game using Microsoft C# w/ XNA, the game requires
the installation of some microsoft proprietary runtimes such as:
.NET, DirectX, XNA Redist.
  
The file setup.exe will install these dependencies (from the internet)
then run the game.

Hopefully this won't be a problem.